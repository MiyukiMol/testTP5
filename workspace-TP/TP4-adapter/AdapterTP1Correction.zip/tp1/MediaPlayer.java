package com.tactfactory.designpatternniveau1.adapter.tp1;

public interface MediaPlayer {
  public void play(String audioType, String fileName);
}
