package com.tactfactory.designpatternniveau1.adapter.tp1;

public interface AdvancedMediaPlayer {
  void playVlc(String fileName);

  void playMp4(String fileName);
}
