package com.tactfactory.designpatternniveau1.factory.tp1;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.tactfactory.designpatternniveau1.factory.tp1.utils.ClassUtils;

public class BuildingFactory {

  public Building createBuilding() {
    Building building = null;

    List<Class<?>> avaiblesClasses = new ArrayList<Class<?>>();
    fillAvaiblesClasses(avaiblesClasses);

    building = initBuilding(building, avaiblesClasses.get(new Random().nextInt(avaiblesClasses.size() - 1)));

    return building;
  }

  public Building createBuilding(String classSimpleName) {
    Building building = null;

    List<Class<?>> avaiblesClasses = new ArrayList<Class<?>>();
    fillAvaiblesClasses(avaiblesClasses);

    for (Class<?> klazz : avaiblesClasses) {
      if (klazz.getSimpleName().toLowerCase().equals(classSimpleName.toLowerCase())) {
        building = initBuilding(building, klazz);
        break;
      }
    }

    return building;
  }

  public Building createBuilding(Class<?> klazz) {
    Building building = null;

    List<Class<?>> avaiblesClasses = new ArrayList<Class<?>>();
    fillAvaiblesClasses(avaiblesClasses);

    if (!Modifier.isAbstract(klazz.getModifiers()) && Modifier.isPublic(klazz.getModifiers())) {
      for (Class<?> kInterface : klazz.getInterfaces()) {
        if (kInterface.equals(Building.class)) {
          building = initBuilding(building, klazz);
          break;
        }
      }
    }

    return building;
  }

  private void fillAvaiblesClasses(List<Class<?>> avaiblesClasses) {
    try {
      Class<?>[] klazzes = ClassUtils
          .getClasses(BuildingFactory.class.getName().replace("." + BuildingFactory.class.getSimpleName(), ""));

      for (Class<?> klazz : klazzes) {
        if (!Modifier.isAbstract(klazz.getModifiers()) && Modifier.isPublic(klazz.getModifiers())) {
          for (Class<?> kInterface : klazz.getInterfaces()) {
            if (kInterface.equals(Building.class)) {
              avaiblesClasses.add(klazz);
              break;
            }
          }
        }
      }
    } catch (ClassNotFoundException | IOException e) {
      e.printStackTrace();
    }
  }

  private Building initBuilding(Building building, Class<?> klazz) {
    try {
      building = (Building) klazz.getConstructor().newInstance();
    } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
        | NoSuchMethodException | SecurityException e) {
      e.printStackTrace();
    }
    return building;
  }
}
