package com.tactfactory.designpatternniveau1.factory.tp1;

public class House implements Building {

}
