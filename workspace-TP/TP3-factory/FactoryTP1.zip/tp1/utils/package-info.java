/**
 * 
 */
/**
 * @author antoine.cronier
 *
 */
package com.tactfactory.designpatternniveau1.factory.tp1.utils;