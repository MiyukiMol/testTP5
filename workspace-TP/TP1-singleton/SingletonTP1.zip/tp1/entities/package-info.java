/**
 * 
 */
/**
 * @author antoine.cronier
 *
 */
package com.tactfactory.designpatternniveau1.singleton.tp1.entities;