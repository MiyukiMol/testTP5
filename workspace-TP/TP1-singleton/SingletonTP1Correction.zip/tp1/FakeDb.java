package com.tactfactory.designpatternniveau1.singleton.tp1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.tactfactory.designpatternniveau1.singleton.tp1.entities.Entity1;

public class FakeDb {

  private FakeDb() {
    for (int i = 0; i < 20; i++) {
      Entity1 e1 = new Entity1();

      autoIncrementId(e1);

      e1.setData("data " + i);
      this.entity1s.add(e1);
    }
  }

  private static FakeDb INSTANCE = null;

  public static synchronized FakeDb getInstance() {
    if (INSTANCE == null) {
      INSTANCE = new FakeDb();
    }
    return INSTANCE;
  }

  private final List<Entity1> entity1s = new ArrayList<Entity1>();

  private void autoIncrementId(Entity1 e1) {
    if (this.entity1s.size() > 0) {
      e1.setId(this.entity1s.stream().max(Comparator.comparingLong(Entity1::getId)).map(x -> x.getId()).get() + 1);
    } else {
      e1.setId(1);
    }
  }

  public List<Entity1> getEntity1s() {
    return Collections.unmodifiableList(this.entity1s);
  }

  public FakeDb addToEntity1s(Entity1 entity1) {
    this.autoIncrementId(entity1);
    this.entity1s.add(entity1);
    return this;
  }
}
