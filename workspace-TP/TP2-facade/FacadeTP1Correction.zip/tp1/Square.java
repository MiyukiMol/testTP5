package com.tactfactory.designpatternniveau1.facade.tp1;

public class Square implements Shape {

	@Override
	public void draw() {
		System.out.println("Square::draw()");
	}
}
