package com.tactfactory.designpatternniveau1.facade.tp1;

public interface Shape {
	void draw();
}
